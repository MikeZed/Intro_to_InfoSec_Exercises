
import itertools

class RepeatedKeyCipher:

    def __init__(self, key: bytes = bytes([0, 0, 0, 0, 0])):
        """Initializes the object with a list of integers between 0 and 255."""
        # WARNING: DON'T EDIT THIS FUNCTION!
        self.key = list(key)


    def encrypt(self, plaintext: str) -> bytes:
        """Encrypts a given plaintext string and returns the ciphertext."""
        plaintext_bytes = plaintext.encode('latin-1')

        # replicate key enough times that repeated_key is at least the length 
        # of the plain_text 
        repeated_key = self.key * (int(len(plaintext) / len(self.key)) + 1)
        
        # XOR each byte of plain_text with its corresponding byte in repeated_key 
        ciphertext = bytes(t ^ k for t, k in zip(plaintext_bytes, repeated_key))

        return ciphertext
        

    def decrypt(self, ciphertext: bytes) -> str:
        """Decrypts a given ciphertext string and returns the plaintext."""
        # use the encrypt function for decryption 
        # XORs cipher_text with the key to get plain_text 
        return (self.encrypt(ciphertext.decode('latin-1'))).decode('latin-1')


class BreakerAssistant:

    def plaintext_score(self, plaintext: str) -> float:
        """Scores a candidate plaintext string, higher means more likely."""
        # Please don't return complex numbers, that would be just annoying.

        weight_word_length = 100
        weight_alpha       = 5

        # split the plain_text to words 
        words = plaintext.split(' ')

        # count number of letters in the plain_text 
        letters_num = sum(c.isalpha() for c in plaintext)    

        # calc score based on the length of each word in text 
        score_word_length = sum(1.0 / (len(word) + 20) for word in words)

        # calc score based on the relative part of the letters in the text 
        # multiplied by the amount of words 
        score_alpha = letters_num / len(plaintext) * ((len(words) + 1))

        total_score = weight_word_length * score_word_length + \
                      weight_alpha       * score_alpha 

        return total_score


    def brute_force(self, cipher_text: bytes, key_length: int) -> str:
        """Breaks a Repeated Key Cipher by brute-forcing all keys."""

        RKC = RepeatedKeyCipher() 

        max_score = 0
        max_score_string = "" 

        current_score = 0
        current_string = "" 

        # iterate over all possible keys 
        for key in range(0, 2** (8 * key_length)):
            
            # decrypt cipher_text with current key and get its plaintext_score
            RKC.key = list(key.to_bytes(key_length, byteorder = "big")) 

            current_string = RKC.decrypt(cipher_text)          
            current_score = self.plaintext_score(current_string)
            
            # check if we got a better score than the current maximum
            # if so, update the current maximum  
            if(current_score > max_score):
                max_score = current_score
                max_score_string = current_string 

        return max_score_string 
 

    def smarter_break(self, cipher_text: bytes, key_length: int) -> str:
        """Breaks a Repeated Key Cipher any way you like."""
         
        # split ciphertext to key_length size blocks, each block used the same key 
        ciphertext_blocks = [cipher_text[i : key_length + i] \
                             for i in range(0, len(cipher_text), key_length)] 
      
        # transpose the blocks, now each block used the same byte of the key 
        ciphertext_blocks = list(itertools.zip_longest(*ciphertext_blocks, fillvalue = 0))
      
        key = [] 

        # brute force each block to get each byte of the key 
        for block in ciphertext_blocks: 

            decrypted_str = self.brute_force(bytes(block), 1)
            
            key.append(block[0] ^ decrypted_str.encode('latin-1')[0])

        # decrypt cipher_text with the key 
        RKC = RepeatedKeyCipher(key)

        return RKC.decrypt(cipher_text) 




