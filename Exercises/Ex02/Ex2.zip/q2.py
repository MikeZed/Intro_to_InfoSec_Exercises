from q2_atm import ATM, ServerResponse

from decimal import Decimal 


def extract_PIN(encrypted_PIN) -> int:
    """Extracts the original PIN string from an encrypted PIN."""

    atm = ATM()
    # go over all possible PINs  
    for PIN in range(0, 10000):
        # check if we got the corrert PIN by encrypting and comparing 
        if(atm.encrypt_PIN(PIN) == encrypted_PIN): 
            return PIN  
        
    # shouldn't get here 
    return -1  


def extract_credit_card(encrypted_credit_card) -> int:
    """Extracts a credit card number string from its ciphertext."""

    atm = ATM()

    credit_card = round(encrypted_credit_card ** (1 / Decimal(atm.rsa_card.e)))

    return credit_card


def forge_signature():
    """Forge a server response that passes verification."""
    # Return a ServerResponse instance.

    status = ATM.CODE_APPROVAL 

    return ServerResponse(status, 1)





