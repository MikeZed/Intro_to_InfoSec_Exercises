#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    int input, output;

    if (argc != 2) {
        printf("USAGE: %s <number>\n", argv[0]);
        return -1;
    }

    input = atoi(argv[1]);

    asm ("MOV   EBX, %0"
        :
        : "r"(input));

    asm (
        /* Your code starts here. */

    "CALL _Get_SqFib_Rec;"
    "JMP _Exit_Program;"


        // -- FUNCTION START --
    "_Get_SqFib_Rec:"

         //Save EBP, ESP and EBX  
        "PUSH EBP;"
        "MOV EBP, ESP;"
        "PUSH EBX;"

        // check if n = EBX <= 0 --> if true return 0
        "MOV EAX, 0;"
        "CMP EBX, 0;"
        "JLE _End;" 

        // check if n = EBX = 1 --> if true return 1 
        "MOV EAX, 1;"
        "CMP EBX, 1;"
        "JE _End;" 

        // calc SqFib(n-1) and store result in the Stack  
        "SUB EBX, 1;"
        "CALL _Get_SqFib_Rec;"
        "PUSH EAX;" 

        // Restore EBX (which is above SqFib(n-1) in the stack)
        "MOV EBX, DWORD PTR [ESP + 4];" 

         // calc SqFib(n-2) (the result is stored in EAX) 
        "SUB EBX, 2;"
        "CALL _Get_SqFib_Rec;"

        // Pop SqFib(n-1) from the Stack 
        "POP EDX;"

        // calc SqFib(n-1)^2 + SqFib(n-2)^2
        "IMUL EDX, EDX;"
        "IMUL EAX, EAX;"
        "ADD EAX, EDX;" 

    "_End:"
        // Restore EBX, EBP and ESP and then return 
        "POP EBX;"
        "MOV ESP, EBP;"
        "POP EBP;"
        "RET;"
        // -- FUNCTION END --

    "_Exit_Program:" 
        /* Your code stops here. */
    );

    asm ("MOV   %0, EAX"
        : "=r"(output));

    printf("%d\n", output);

    return 0;
}
