#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    int input, output;

    if (argc != 2) {
        printf("USAGE: %s <number>\n", argv[0]);
        return -1;
    }

    input = atoi(argv[1]);

    asm ("MOV   EBX, %0"
        :
        : "r"(input));

    asm (
        /* Your code starts here. */
    
    "CALL _Get_Exact_Root;"
    "JMP _Exit_Program;"

        // -- FUNCTION START --
    "_Get_Exact_Root:"

        // init EAX with 0
        "MOV EAX, 0;" 

        // check if EBX is less than 1 --> if it is, exit 
        "CMP EBX, 1;" 
        "JL _End;"

        // iterate over the numbers from 0 to EBX, 
        // compute ECX^2 and compare it with EBX 
        // --> if equal we found the exact square root 
        "MOV ECX, 0;"

    "_Loop:"
        "MOV EDX, ECX;"
        "IMUL EDX, EDX;"

        "CMP EDX, EBX;"
        "JE _Root_Found;"

        "INC ECX;"
        "CMP ECX, EBX;"
        "JLE _Loop;"
        "JMP _End;"

        // if root found EAX=ECX
    "_Root_Found:"
        "MOV EAX, ECX;"
    "_End:"
        "RET;"
        // -- FUNCTION END --

    "_Exit_Program:" 

        /* Your code stops here. */
    );

    asm ("MOV   %0, EAX"
        : "=r"(output));

    printf("%d\n", output);

    return 0;
}
