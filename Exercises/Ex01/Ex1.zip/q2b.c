#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    int input, output;

    if (argc != 2) {
        printf("USAGE: %s <number>\n", argv[0]);
        return -1;
    }

    input = atoi(argv[1]);

    asm ("MOV   EBX, %0"
        :
        : "r"(input));

    asm (
        /* Your code starts here. */

    "CALL _Get_SqFib_Iter;"
    "JMP _Exit_Program;"


        // -- FUNCTION START --
    "_Get_SqFib_Iter:" 

        // check if n = EBX <= 0 --> if true return 0
        "MOV EAX, 0;"
        "CMP EBX, 0;"
        "JLE _End;" 

        // init EAX = SqFib(1) = 1, EDX = SqFib(0) = 0
        "MOV EAX, 1;"
        "MOV EDX, 0;" 
        
        // Loop from n=2 to n=EBX
        "MOV ECX, 2;"
    "_Loop:"
   
        // push SqFib(n-1) to stack 
        "PUSH EAX;"

        // calc EAX = SqFib(n)^2 + SqFib(n-1)^2 
        "IMUL EDX, EDX;"
        "IMUL EAX, EAX;"
        "ADD EAX, EDX;" 

        // pop SqFib(n-1) from stack to EDX
        "POP EDX;" 

        "INC ECX;"
        "CMP ECX, EBX;"
        "JLE _Loop;"

    "_End:"
        "RET;"
        // -- FUNCTION END --

    "_Exit_Program:" 
        /* Your code stops here. */
    );

    asm ("MOV   %0, EAX"
        : "=r"(output));

    printf("%d\n", output);

    return 0;
}
