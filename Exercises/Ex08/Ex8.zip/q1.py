import scapy.all as S
import urllib.parse as urlparse
from typing import Tuple


WEBSITE = 'infosec.cs.tau.ac.il'


def parse_packet(packet) -> Tuple[str]:
    """
    If the given packet is a login request to the course website, return the
    username and password as a tuple => ('123456789', 'opensesame'). Otherwise,
    return None.

    Notes:
    1. You can assume the entire HTTP request fits within one packet, and that
       both the username and password are non-empty for login requests (if any
       of the above assumptions fails, it's OK if you don't extract the
       user/password - but you must still NOT crash).
    2. Filter the course website using the `WEBSITE` constant from above. DO NOT
       use the server IP for the filtering (as our domain may point to different
       IPs later and your code should be reliable).
    3. Make sure you return a tuple, not a list.
    """
    # just in case - use try except block to avoid crashing 
    try: 

        # make sure there is a Raw layer in the packet (that contains the HTTP requests)
        if(S.Raw not in packet):
            return None

        packet_load = (packet[S.Raw].load).decode("latin-1")

        # check if packet is a login attempt to the course website 
        if(("Host: " + WEBSITE) not in packet_load or "POST" not in packet_load): 
            return None  

        # parse packet with parse_qs 
        parsed_packet = urlparse.parse_qs(packet_load)

        # initialize username and password 
        username = None
        password = None 

        # check for username field, if there is one store it in the username variable 
        if "username" in parsed_packet:
            username = parsed_packet["username"][0] 

        # check for password field, if there is one store it in the password variable 
        if "password" in parsed_packet:
            password = parsed_packet["password"][0]

        return (username, password)

    except Exception: 
        return None 


def packet_filter(packet) -> bool:
    """
    Filter to keep only HTTP traffic (port 80) from any HTTP client to any
    HTTP server (not just the course website). This function should return
    `True` for packets that match the above rule, and `False` for all other
    packets.

    Notes:
    1. We are only keeping HTTP, while dropping HTTPS
    2. Traffic from the server back to the client should not be kept
    """
    # just in case - use try except block to avoid crashing 
    try: 

        # check for TCP layer in packet, if there is one - check if destination port is 80
        if(S.TCP in packet): 
            if (packet[S.TCP].dport == 80):
                return True

        # check for UDP layer in packet, if there is one - check if destination port is 80
        if(S.UDP in packet): 
            if (packet[S.UDP].dport == 80):
                return True 
        
        # the destination port is not 80 (HTTP) --> return false 
        return False 

    except Exception: 
        return False


def main(args):
    # WARNING: DO NOT EDIT THIS FUNCTION!
    if '--help' in args:
        print('Usage: %s [<path/to/recording.pcapng>]' % args[0])

    elif len(args) < 2:
        # Sniff packets and apply our logic.
        S.sniff(lfilter=packet_filter, prn=parse_packet)

    else:
        # Else read the packets from a file and apply the same logic.
        for packet in S.rdpcap(args[1]):
            if packet_filter(packet):
                print(parse_packet(packet))


if __name__ == '__main__':
    import sys
    main(sys.argv)
