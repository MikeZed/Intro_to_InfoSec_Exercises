def check_message(path: str) -> bool:
    """
    Return True if `msgcheck` would return 0 for the file at the specified path,
    return False otherwise.
    :param path: The file path.
    :return: True or False.
    """
    with open(path, 'rb') as reader:
        buffer = reader.read(1024)

        chars_to_read = buffer[0]
        desired_xor_result = buffer[1]
        xor_result = 0x0CE
        
        for i in range(0, chars_to_read, 1):
            if(i+2 >= len(buffer)):
                break 

            xor_result = xor_result ^ buffer[i+2]
      
        return (desired_xor_result == xor_result)
 

def main(argv):
    if len(argv) != 2:
        print('USAGE: python {} <msg-file>'.format(argv[0]))
        return -1
    path = argv[1]
    if check_message(path):
        print('valid message')
        return 0
    else:
        print('invalid message')
        return 1


if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
