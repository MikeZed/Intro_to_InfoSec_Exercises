def fix_message_data(data: bytes) -> bytes:
    """
    Implement this function to return the "fixed" message content. This message
    should have minimal differences from the original message, but should pass
    the check of `msgcheck`.

    :param data: The source message data.
    :return: The fixed message data.
    """
    # we will fix the message by changing the second char of the data 
    # (the desired XOR result) to the actual XOR result
    chars_to_read = data[0]

    xor_result = 0x0CE

    for i in range(0, chars_to_read, 1):
        if(i+2 >= len(data)):
            break 

        xor_result = xor_result ^ data[i+2]

    # data[0:1] is data[0] 
    data = data[0:1] + xor_result.to_bytes(1, byteorder = "big") + data[2:]
    return data 


def fix_message(path):
    with open(path, 'rb') as reader:
        data = reader.read()
    fixed_data = fix_message_data(data)
    with open(path + '.fixed', 'wb') as writer:
        writer.write(fixed_data)


def main(argv):
    if len(argv) != 2:
        print('USAGE: python {} <msg-file>'.format(argv[0]))
        return -1
    path = argv[1]
    fix_message(path)
    print('done')


if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
