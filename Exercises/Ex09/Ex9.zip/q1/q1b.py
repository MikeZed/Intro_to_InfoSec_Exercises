import time
import os
from scapy.all import *


WINDOW = 60
MAX_ATTEMPTS = 15


# Initialize your data structures here
# TODO: Initialize your data structures
syn_times_per_ip_dict = dict()

blocked = set()  # We keep blocked IPs in this set


def on_packet(packet):
    """This function will be called for each packet.

    Use this function to analyze how many packets were sent from the sender
    during the last window, and if needed, call the 'block(ip)' function to
    block the sender.

    Notes:
    1. You must call block(ip) to do the blocking.
    2. The number of SYN packets is checked in a sliding window.
    3. Your implementation should be able to efficiently handle multiple IPs.
    """

    SYN_flag_value = 0x02 
    
    # make sure it's a SYN packet 
    if(IP not in packet or TCP not in packet):
        return 
 
    if(packet[TCP].flags != SYN_flag_value):
        return 
    

    sender_ip = packet[IP].src
    current_time = time.time()

    # check if ip is already blocked
    if(is_blocked(sender_ip)):
        return 

    # if ip not in the data struct (a dictionary), add it with current time
    if(sender_ip not in syn_times_per_ip_dict): 
        syn_times_per_ip_dict[sender_ip] = [current_time] 
    # ip is alreay in the dict, add current attempt to the list (the value for this key) 
    else: 
        syn_times_per_ip_dict[sender_ip].append(current_time)

    # remove old SYN packet times from list for current ip     
    for syn_time in syn_times_per_ip_dict[sender_ip]:
        if (current_time - syn_time > WINDOW): 
            syn_times_per_ip_dict[sender_ip].remove(syn_time)
        else: 
            break 
    
    # check if there are more then MAX_ATTEMPTS SYN packet times in the list 
    # if there are --> block the ip 
    if(len(syn_times_per_ip_dict[sender_ip]) > MAX_ATTEMPTS): 
        block(sender_ip)
           


def generate_block_command(ip: str) -> str:
    """Generate a command that when executed in the shell, blocks this IP.

    The blocking will be based on `iptables` and must drop all incoming traffic
    from the specified IP."""

    return "iptables -I INPUT -s {} -j DROP".format(ip) 



def block(ip):
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    os.system(generate_block_command(ip))
    blocked.add(ip)


def is_blocked(ip):
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    return ip in blocked


def main():
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    sniff(prn=on_packet)


if __name__ == '__main__':
    main()
