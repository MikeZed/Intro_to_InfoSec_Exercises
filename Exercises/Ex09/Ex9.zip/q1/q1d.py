from scapy.all import *


def on_packet(packet):
    """Implement this to send a SYN ACK packet for every SYN.

    Notes:
    1. Use *ONLY* the `send` function from scapy to send the packet!
    """

    SYN_flag_value = 0x02 

    # make sure it's a SYN packet 
    if(IP not in packet or TCP not in packet):
        return 
 
    if(packet[TCP].flags != SYN_flag_value):
        return 
    
    # build the SYN-ACK packet
    packet_to_send = IP(src=packet[IP].dst ,dst=packet[IP].src) 
    packet_to_send = packet_to_send / TCP(sport=packet[TCP].dport, \
                     dport=packet[TCP].sport,  ack=packet[TCP].seq+1, flags='SA')

    # send the packet 
    send(packet_to_send)



def main(argv):
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    sniff(prn=on_packet)


if __name__ == '__main__':
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    import sys
    sys.exit(main(sys.argv))
