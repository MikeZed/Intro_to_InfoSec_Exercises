from scapy.all import *
from typing import List, Iterable


OPEN = 'open'
CLOSED = 'closed'
FILTERED = 'filtered'


def generate_syn_packets(ip: str, ports: List[int]) -> list:
    """
    Returns a list of TCP SYN packets, to perform a SYN scan on the given
    TCP ports.

    Notes:
    1. Do NOT add any calls of your own to send/receive packets.
    """

    # create a syn packet for each port 
    syn_packets = [(IP(dst=ip) / TCP(dport=port,flags="S")) for port in ports]
    return syn_packets



def analyze_scan(ip: str, ports: List[int], answered: Iterable, unanswered: Iterable) -> dict:
    """Analyze the results from `sr` of SYN packets.

    This function returns a dictionary from port number (int), to
    'open' / 'closed' / 'filtered' (strings), based on the answered and unanswered
    packets returned from `sr`.

    Notes:
    1. Use the globals OPEN / CLOSED / FILTERED as declared above.
    """
    # numeric value of the SA flag
    SA_value = 0x02+0x10

    results = dict()

    # iterate over every port 
    for port in ports:
        
        for answer in answered: 
            answer = answer[1]
            if (TCP not in answer):
                return results 
            # check if the answer is for this port 
            if (answer[TCP].sport == port): 
                # if it is --> check if the port is open by checking the flags value
                #    SA = 0x12 --> open 
                #    RA = 0x14 --> closed 
                results[port] = OPEN if (answer[TCP].flags == SA_value) else CLOSED 
        # if no answer for this port --> it is filtered 
        if(port not in results):
            results[port] = FILTERED

    return results 



def stealth_syn_scan(ip: str, ports: List[int], timeout: int):
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    packets = generate_syn_packets(ip, ports)
    answered, unanswered = sr(packets, timeout=timeout)
    return analyze_scan(ip, ports, answered, unanswered)


def main(argv):
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    if not 3 <= len(argv) <= 4:
        print('USAGE: %s <ip> <ports> [timeout]' % argv[0])
        return 1
    ip = argv[1]
    ports = [int(port) for port in argv[2].split(',')]
    if len(argv) == 4:
        timeout = int(argv[3])
    else:
        timeout = 5
    results = stealth_syn_scan(ip, ports, timeout)
    for port, result in results.items():
        print('port %d is %s' % (port, result))


if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
