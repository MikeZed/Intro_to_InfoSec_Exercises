import socket
from Crypto.Cipher import AES

import base64


KEY = 'This is a great key 123, and I will add some characters to make sure it is long enough'
unpad = lambda s: s[:-ord(s[-1:])]


def receive_message(port: int) -> str:
    """Receive *encrypted* messages on the given TCP port.

    As Winston sends encrypted messages, re-implement this function so to
    be able to decrypt the messages.

    Notes:
    1. The encryption is based on AES.
    2. Julia and Winston already have a common shared key, just define it on your own.
    3. Mind the padding! AES works in blocks of 16 bytes.
    """

    listener = socket.socket()
    try:
        listener.bind(('', port))
        listener.listen(1)
        connection, address = listener.accept()
        try:
            # receive the encrypted message 
            encrypted_message = connection.recv(1024)

            # decode the message with base64
            encrypted_message = base64.b64decode(encrypted_message)

            # get the iv from the message 
            iv = encrypted_message[:AES.block_size]

            # set the parameters for the cipher - take the first 32 bytes of the key,
            # set the mode to MODE_CBC and set the iv 
            aes_cipher = AES.new(KEY[:32], AES.MODE_CBC, iv)

            # decrypt the encrypted message without the iv 
            decrypted_message = aes_cipher.decrypt(encrypted_message[AES.block_size:])
            
            # unpad the decrypted message 
            decrypted_message = unpad(decrypted_message).decode("latin-1") 

            # return the decrypted message 
            return decrypted_message

        finally:
            connection.close()
    finally:
        listener.close()


def main():
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    message = receive_message(1984)
    print('received: %s' % message)


if __name__ == '__main__':
    main()
