import socket
from Crypto.Cipher import AES


from Crypto import Random
import base64

MESSAGE_TO_SEND = "I love you"
KEY = 'This is a great key 123, and I will add some characters to make sure it is long enough'


pad = lambda s: (s + (AES.block_size - len(s) % AES.block_size) * chr(AES.block_size - len(s) % AES.block_size))


def send_message(ip: str, port: int):
    """Send an *encrypted* message to the given ip + port.

    Julia expects the message to be encrypted, so re-implement this function accordingly.

    Notes:
    1. The encryption is based on AES.
    2. Julia and Winston already have a common shared key, just define it on your own.
    3. Mind the padding! AES works in blocks of 16 bytes.
    """

    connection = socket.socket()
    try:
        # connect to julia 
        connection.connect((ip, port))
        
        # pad the message we want to send 
        padded_message = pad(MESSAGE_TO_SEND)

        # get some random iv with length of 16 bytes 
        iv = Random.new().read(AES.block_size)

        # set the parameters for the cipher - take the first 32 bytes of the key,
        # set the mode to MODE_CBC and set the iv 
        aes_cipher = AES.new(KEY[:32], AES.MODE_CBC, iv)

        # encrypt the padded message 
        encrypted_message = aes_cipher.encrypt(padded_message)

        # encode the iv and encrypted message with base64
        encrypted_message = base64.b64encode(iv + encrypted_message)

        # send the encrypted message
        connection.send(encrypted_message)

    finally:
        connection.close()


def main():
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    send_message('127.0.0.1', 1984)


if __name__ == '__main__':
    main()
