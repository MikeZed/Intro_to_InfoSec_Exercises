import socket

from scapy.all import * 


SRC_PORT = 65000

MESSAGE = "I love you"



def send_message(ip: str, port: int):
    """Send a *hidden* message to the given ip + port.

    Julia expects the message to be hidden in the TCP metadata, so re-implement
    this function accordingly.

    Notes:
    1. Use `SRC_PORT` as part of your implementation.
    """
    # convert string to list of bytes - for each char: char --> int --> 8 bits 
    data_bits = ['{0:08b}'.format(ord(ch), 'b') for ch in MESSAGE]

    # list of bytes --> string of bits 
    data_bits = ''.join(data_bits)

    # split string of bits into groups of 3 
    data_bits = [data_bits[i:i+3] for i in range(0, len(data_bits), 3)] 

    # pad last triplet to 3 bits 
    data_bits[-1] += (3 - len(data_bits[-1])) * '0'

    # build all the packets 
    packets = [(IP(dst=ip) / TCP(sport=SRC_PORT, dport=port, flags="SA", \
                ack=len(data_bits), seq=i, reserved=int(bits, 2))) 
                for i,bits in enumerate(data_bits)]

    # send packets
    send(packets)



def main():
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    send_message('127.0.0.1', 1984)


if __name__ == '__main__':
    main()
