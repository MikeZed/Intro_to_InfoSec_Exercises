import socket


from scapy.all import * 

SRC_PORT = 65000



def receive_message(port: int) -> str:
    """Receive *hidden* messages on the given TCP port.

    As Winston sends messages encoded over the TCP metadata, re-implement this
    function so to be able to receive the messages correctly.

    Notes:
    1. Use `SRC_PORT` as part of your implementation.
    """
    # initialize an empty set to hold the data 
    enumerated_data_bits = set()
    
    # handle received packet 
    def handle_packet(packet):
        # make sure there is a TCP layer in the packet 
        if (TCP not in packet): 
            return 

        # make sure the ports are correct 
        if(packet[TCP].sport != SRC_PORT or packet[TCP].dport != port): 
            return 

        # make sure it's a SYN ACK packet  
        if(packet[TCP].flags != 0x12): # 0x12=SYN ACK 
            return 

        # add packet seq number and reserved bits to the set 
        enumerated_data_bits.add((packet[TCP].seq, '{0:03b}'.format(packet[TCP].reserved, 'b')))

    # check if we should stop sniffing 
    def check_if_finished(packet):
        # make sure there is a TCP layer in the packet 
        if (TCP not in packet): 
            return False

        # check if we received all the packets 
        return (len(enumerated_data_bits) == packet[TCP].ack)
 
    # sniff all packets 
    sniff(prn=handle_packet, stop_filter=check_if_finished)

    # sort the received bits according to the seq number 
    data_bits = sorted(list(enumerated_data_bits), key=lambda tup: tup[0])

    # remove the seq number from the sorted received bits 
    data_bits = [tup[1] for tup in data_bits]

    # calc redundant bits amount 
    redundant_bit_num = (len(data_bits) * 3) % 8  
    
    # remove redundant bits from last packet 
    data_bits[-1] = data_bits[-1][: 3-redundant_bit_num]

    # list of triplets of bits --> string of bits 
    data_bits = ''.join(data_bits)

    # string of bits --> list of bytes 
    data_bytes = bytes([int(data_bits[i:i+8], 2) for i in range(0, len(data_bits), 8)])

    # decode the list of bytes and return it 
    return data_bytes.decode("latin-1") 


def main():
    # WARNING: DO NOT MODIFY THIS FUNCTION!
    message = receive_message(1984)
    print('received: %s' % message)


if __name__ == '__main__':
    main()
